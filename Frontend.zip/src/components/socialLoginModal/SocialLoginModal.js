import { useState, useEffect } from "react";
import { googleLogout } from "@react-oauth/google";

import GoogleButton from "../socialLoginButtons/googleButton";
import KakaoButton from "../socialLoginButtons/kakaoButton";
import NaverButton from "../socialLoginButtons/naverButton";

function SocialLoginModal() {
  const [profile, setProfile] = useState(null);
  const [isLogin, setIsLogin] = useState(false);

  const handleProfileChange = (profile) => {
    setProfile(profile);
  };

  const Logout = () => {
    if (profile) {
      switch (profile.type) {
        case "google":
          googleLogout();
          break;
        case "naver":
          localStorage.removeItem("com.naver.nid.access_token");
          break;
        case "kakao":
          break;
      }
      setProfile(null);
    }
  };

  const openSocialLoginModal = () => {
    setIsLogin(true);
  };

  console.log(profile);

  useEffect(() => {}, []);

  return (
    <div>
      <button onClick={openSocialLoginModal}>로그인</button>

      {isLogin ? (
        <div>
          {!profile ? (
            <div>
              <GoogleButton onProfileChange={handleProfileChange} />
              <br />
              <KakaoButton onProfileChange={handleProfileChange} />
              <br />
              <NaverButton onProfileChange={handleProfileChange} />
            </div>
          ) : (
            <>
              <h1>로그인 완료</h1>
              <img src={profile.picture} alt="user image" />
              <p>{profile.type} 로그인</p>
              <p>이름 : {profile.name}</p>
              <p>이메일: {profile.email}</p>

              <button onClick={Logout}>로그아웃</button>
            </>
          )}
        </div>
      ) : (
        <></>
      )}
    </div>
  );
}

export default SocialLoginModal;
